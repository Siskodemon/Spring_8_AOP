package com.evilcorp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AopSpringTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
