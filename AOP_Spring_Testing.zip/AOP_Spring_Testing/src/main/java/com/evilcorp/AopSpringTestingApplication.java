package com.evilcorp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AopSpringTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AopSpringTestingApplication.class, args);
	}

}
